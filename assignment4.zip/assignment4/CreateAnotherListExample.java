package assignment4;

import java.util.ArrayList;

public class CreateAnotherListExample {

	public static void main(String[] args) {
		ArrayList<String> testingTechnologies = new ArrayList<String>();
		ArrayList<String> gitOptions = new ArrayList<String>();
		testingTechnologies.add("Git");
		testingTechnologies.add("Github");
		testingTechnologies.add("GitLab");
		testingTechnologies.add("GitBash");
		testingTechnologies.add("Selenium");
		testingTechnologies.add("Java");
		testingTechnologies.add("Maven");
		for(String technology : testingTechnologies)
		{
			if(technology.toLowerCase().startsWith("git"))
			{
				gitOptions.add(technology);
			}
		}
		System.out.println("Git values in the List "+gitOptions);
	}

}
