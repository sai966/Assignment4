package assignment4;

import java.util.ArrayList;
import java.util.Arrays;

public class PrintSecondLastElement {

	public static void main(String[] args) {
		ArrayList<Integer> integerList = new ArrayList<Integer>(Arrays.asList(10,45,90,45,23,90,44));
		System.out.println("Second Element of the List "+integerList.get(1));
		System.out.println("Last Second Element of the List "+integerList.get(integerList.size()-2));
	}

}
