package assignment4;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicateValues {

	public static void main(String[] args) {
		ArrayList<String> testingTechnologies = new ArrayList<String>();
		testingTechnologies.add("Java");
		testingTechnologies.add("TestNG");
		testingTechnologies.add("Maven");
		testingTechnologies.add("Java");
		System.out.println("Before removal of Duplicate Values "+testingTechnologies);
		Set<String> uniquevalues = new HashSet<String>(testingTechnologies);
		System.out.println("After removal of Duplicate Values "+uniquevalues);
	}
}
