package assignment4;

import java.util.ArrayList;
import java.util.Arrays;

public class NestedArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> arrayList1 = new ArrayList<Integer>(Arrays.asList(11,22,33));
		ArrayList<Integer> arrayList2 = new ArrayList<Integer>(Arrays.asList(9,19,29));
		ArrayList<Integer> arrayList3 = new ArrayList<Integer>(Arrays.asList(7,17,27));
		ArrayList<ArrayList<Integer>> nestedList = new ArrayList<ArrayList<Integer>>();
		nestedList.add(arrayList1);
		nestedList.add(arrayList2);
		nestedList.add(arrayList3);
		System.out.println("Nested List values are "+nestedList);
	}

}
