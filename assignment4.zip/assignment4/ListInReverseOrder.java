package assignment4;

import java.util.ArrayList;
import java.util.Collections;

public class ListInReverseOrder {

	public static void main(String[] args) {
		ArrayList<String> testingTechnologies = new ArrayList<String>();
		testingTechnologies.add("Java");
		testingTechnologies.add("Selenium");
		testingTechnologies.add("TestNG");
		testingTechnologies.add("Git");
		testingTechnologies.add("Github");
		System.out.println("Before Reversing the List "+testingTechnologies);
		//Using Inbuilt Technologies
		Collections.reverse(testingTechnologies);
		System.out.println("After Reversing the List "+testingTechnologies);
		//Using for loop
		for(int technology = testingTechnologies.size()-1;technology >= 0;technology--)
		{
			System.out.print(testingTechnologies.get(technology)+ " ");
		}
	}

}
